package com.jiudian.service;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

import com.jiudian.pojo.Dingdan;

 
public interface DingdanService{
	public List<Dingdan> queryDingdanList(Dingdan dingdan) throws Exception;
 
	//数据统计
  	public List<Dingdan> selectShuJuTongJi(Timestamp min, Timestamp max);
	
	public int insertDingdan(Dingdan dingdan) throws Exception ;
	
	public int deleteDingdan(int id) throws Exception ;
	
	public int updateDingdan(Dingdan dingdan) throws Exception ;
	
	public Dingdan queryDingdanById(int id) throws Exception;
	
	public void qxDingdan(Dingdan dingdan) throws Exception ;
	
	public void qrDingdan(Dingdan dingdan) throws Exception ;
}
