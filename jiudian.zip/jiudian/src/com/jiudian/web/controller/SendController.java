/*package com.jiudian.web.controller;
import org.apache.commons.httpclient.HttpException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.jiudian.pojo.Loginuser;
import com.jiudian.service.IPhoneService;

 
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.HashMap;
 
*//**
 * Created by Administrator on 2018/9/6.
 *//*
@Controller
public class SendController {


	 
	    @Autowired
	    private IPhoneService iPhoneService;
	 
	    @Autowired
	    private Loginuser loginuser;
	 
	    @ResponseBody
	    @RequestMapping(value = "/sendme", method = RequestMethod.GET)
	    public ModelAndView sendme(@RequestParam(value = "name") String name,@RequestParam(value = "phone") String phone, HttpServletRequest request) throws HttpException, IOException {
	        ModelAndView model = new ModelAndView();
	        String str = request.getParameter("name");
	        name = new String(str.getBytes("iso-8859-1"),"UTF-8");
	        boolean flag = iPhoneService.loginList(name,phone);
	        if (flag) {
	            HashMap<String,String> hashMap = SendUtil.getMessageStatus(phone);
	            String result = hashMap.get("result");
	            if (result.trim().equals("1")) {
	                String code = hashMap.get("code");
	                HttpSession session = request.getSession();
	                session.setAttribute(phone+"code",code);
	                session.setMaxInactiveInterval(60*5);
	                model.addObject("flag","发送成功");
	            } else {
	                model.addObject("flag", "发送失败");
	            }
	            model.addObject("name",name);
	            model.addObject("phone",phone);
	            model.setViewName("register.jsp");
	        } else {
	            model.addObject("flag1", "用户名或手机号码不正确");
	            model.addObject("name", name);
	            model.addObject("phone",phone);
	            model.setViewName("register.jsp");
	        }
	        return model;
	    }
	 
	    @RequestMapping(value = "/comparecode", method = RequestMethod.GET)
	    public ModelAndView comparecode(@RequestParam(value = "code") String code, Loginuser loginuser,HttpServletRequest request, HttpServletResponse response) throws IOException {
	        ModelAndView model = new ModelAndView();
	        String str1 = request.getParameter("name");
	        String str2 = request.getParameter("pass");
	        String name = new String(str1.getBytes("iso-8859-1"), "UTF-8");
	       //.........
	        HttpSession session = request.getSession();//设置session
	        String sessionCode = (String) session.getAttribute(loginuser.getTelphone()+"code");
	        System.out.println(sessionCode);
	        if (code.equals(sessionCode)) {
	            model.addObject("result", "修改密码成功");
	        } else {
	            model.addObject("result", "验证码不正确");
	            model.setViewName("register.jsp");
	        }
	        model.setViewName("result.jsp");
	 
	        return model;
	    }
	 
	}

*/