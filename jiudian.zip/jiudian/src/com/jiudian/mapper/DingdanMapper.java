package com.jiudian.mapper;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.jiudian.pojo.Dingdan;

public interface DingdanMapper {
	public List<Dingdan> findDingdanList();
	
	public List<Dingdan> query(Map<String,Object> inputParam);
	
	public int insertDingdan(Dingdan dingdan);
	
	public int deleteDingdan(int id);
	
	public int updateDingdan(Dingdan dingdan);
	
	public Dingdan queryDingdanById(int id);
	
	public Dingdan selectShuJuTongJi(@Param("min")Timestamp min, @Param("max")Timestamp max);//做图表
	
	public void qxDingdan(Dingdan dingdan);
	
	public void qrDingdan(Dingdan dingdan);//确认订单
	
}
