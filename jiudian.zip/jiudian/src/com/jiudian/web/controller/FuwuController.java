package com.jiudian.web.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.jiudian.pojo.Fuwu;
import com.jiudian.service.FuwuService;
 
@Controller
@RequestMapping("/fuwu")
public class FuwuController {
	@Autowired
	private FuwuService fuwuService;
	
	@RequestMapping(value="/list")
	public String list(Fuwu fuwu,HttpServletRequest request) throws Exception{
		List<Fuwu> list = fuwuService.queryFuwuList(fuwu);
		request.setAttribute("fuwuList", list);
		return "/fuwu/fuwulist.jsp";
	}
	
	@RequestMapping(value="/addfuwu")
	public String addfuwu(Fuwu fuwu,HttpServletRequest request) throws Exception{
		fuwu.setPic(fuwu.getFujian());
		fuwuService.insertFuwu(fuwu);
		fuwu=new Fuwu();
		return this.list(fuwu, request);
	}
	
	@RequestMapping(value="/toupdatefuwu")
	public String toupdatefuwu(int id,HttpServletRequest request) throws Exception{
		Fuwu fuwu=fuwuService.queryFuwuById(id);
		request.setAttribute("fuwu", fuwu);
		return "/fuwu/fuwuupdate.jsp";
	}
	
	@RequestMapping(value="/deletefuwu")
	public String deletefuwu(int id,HttpServletRequest request) throws Exception{
		fuwuService.deleteFuwu(id);
		return "/fuwu/list";
	}
	
	@RequestMapping(value="/updatefuwu")
	public String updatefuwu(Fuwu fuwu,HttpServletRequest request) throws Exception{
		fuwu.setPic(fuwu.getFujian());
		fuwuService.updateFuwu(fuwu);
		fuwu=new Fuwu();
		return this.list(fuwu, request);
	}
	
}
