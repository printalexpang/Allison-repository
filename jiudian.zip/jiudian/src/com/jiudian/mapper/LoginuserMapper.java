package com.jiudian.mapper;

import java.util.List;
import java.util.Map;

import com.jiudian.pojo.Loginuser;

 
public interface LoginuserMapper {
	public List<Loginuser> findLoginuserList();
	
	public List<Loginuser> query(Map<String,Object> inputParam);
	
	public int insertLoginuser(Loginuser loginuser);
	
	public int deleteLoginuser(int id);
	
	public int updateLoginuser(Loginuser loginuser);
	
	public Loginuser queryLoginuserById(int id);
	
	/*public List<Loginuser> selectShuJuTongJi();*/
}
