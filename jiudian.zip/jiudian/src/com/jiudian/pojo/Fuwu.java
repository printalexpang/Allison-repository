package com.jiudian.pojo;

import java.io.Serializable;

import com.jiudian.util.HtmlSplit;

 
public class Fuwu implements Serializable{
 
 
	private static final long serialVersionUID = 1L;
	private Integer id;//主键
	private String name; 
	private String ms;  
	private String jg;
	private String pic;
	private String fujian;
	private String mss;  
	
	public String getMss() {
		if(ms!=null && !ms.equals("")){
			mss = HtmlSplit.delHTMLTag(ms);
		}
		return mss;
	}
	public void setMss(String mss) {
		this.mss = mss;
	}
	public String getFujian() {
		return fujian;
	}
	public void setFujian(String fujian) {
		this.fujian = fujian;
	}
	public String getPic() {
		return pic;
	}
	public void setPic(String pic) {
		this.pic = pic;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMs() {
		return ms;
	}
	public void setMs(String ms) {
		this.ms = ms;
	}
	public String getJg() {
		return jg;
	}
	public void setJg(String jg) {
		this.jg = jg;
	}
	
	
	
    
}
