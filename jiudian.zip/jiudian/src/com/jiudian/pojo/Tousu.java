package com.jiudian.pojo;

import java.io.Serializable;

 
public class Tousu implements Serializable{
 
 
	private static final long serialVersionUID = 1L;
	private Integer id;//主键
	private String title;
	private String ms;
	private String tsr;
	private String tssj;
	private String replay;
	private String hfsj;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getMs() {
		return ms;
	}
	public void setMs(String ms) {
		this.ms = ms;
	}
	public String getTsr() {
		return tsr;
	}
	public void setTsr(String tsr) {
		this.tsr = tsr;
	}
	public String getTssj() {
		return tssj;
	}
	public void setTssj(String tssj) {
		this.tssj = tssj;
	}
	public String getReplay() {
		return replay;
	}
	public void setReplay(String replay) {
		this.replay = replay;
	}
	public String getHfsj() {
		return hfsj;
	}
	public void setHfsj(String hfsj) {
		this.hfsj = hfsj;
	}
}
