package com.jiudian.service;

import java.sql.Timestamp;
import java.util.List;

import com.jiudian.pojo.Loginuser;
 
public interface LoginuserService{
	public List<Loginuser> queryLoginuserList(Loginuser loginuser) throws Exception;
	
	public int insertLoginuser(Loginuser loginuser) throws Exception ;
	
	public int deleteLoginuser(int id) throws Exception ;
	
	public int updateLoginuser(Loginuser loginuser) throws Exception ;
	
	public Loginuser queryLoginuserById(int id) throws Exception ;
	
	public List<Loginuser> selectMoney(int id);//查询用于计算房间加商品消费
	
	public List<Loginuser> selectConsumption(int id);//根据 顾客id 来查询 消费
	
    public List<Loginuser> selectPayXiaoFei();//根据 已结账 来查询 旅客总消费。无条件
    
  //数据统计
  	public List<Loginuser> selectShuJuTongJi(Timestamp min, Timestamp max);
}
