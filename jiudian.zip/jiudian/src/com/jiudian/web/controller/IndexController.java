package com.jiudian.web.controller;

 

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.jiudian.pojo.Dingdan;
import com.jiudian.pojo.Fuwu;
import com.jiudian.pojo.Huodong;
import com.jiudian.pojo.Jiudian;
import com.jiudian.pojo.Kefang;
import com.jiudian.pojo.Loginuser;
import com.jiudian.pojo.Tousu;
import com.jiudian.pojo.User;
import com.jiudian.service.DingdanService;
import com.jiudian.service.FuwuService;
import com.jiudian.service.HuodongService;
import com.jiudian.service.JiudianService;
import com.jiudian.service.KefangService;
import com.jiudian.service.LoginuserService;
import com.jiudian.service.TousuService;
import com.jiudian.service.UserService;

 
@Controller
@RequestMapping("/index")
public class IndexController {
	@Autowired
	private UserService userService;
	
	@Autowired
	private DingdanService dingdanService;
	
	@Autowired
	private KefangService kefangService;
	
	@Autowired
	private LoginuserService loginuserService;
	
	
	@Autowired
	private HuodongService huodongService;
	
	@Autowired
	private FuwuService fuwuService;
	
	@Autowired
	private JiudianService jiudianService;
	
	@Autowired
	private TousuService tousuService;
	
	@RequestMapping(value = "/login")
	public String login(HttpServletRequest request) throws Exception {
		String username = request.getParameter("username");
		String pwd = request.getParameter("pwd");
		 
		 
		User user = userService.login(username, pwd);
		if (user != null) {
			request.getSession().setAttribute("username",
					user.getUsername());
			request.getSession().setAttribute("user", user);
			return "/index.jsp";
		} else {
			request.setAttribute("messageInfo", "用户名或密码有误");
			return "/login.jsp";
		}
		 

	}
	
	@RequestMapping(value = "/loginout")
	public String loginout(HttpServletRequest request) throws Exception {
		request.getSession().invalidate();
		return "/login.jsp";
	}
	
	

	@RequestMapping(value="/index")
	public String index(Kefang kefang,HttpServletRequest request) throws Exception{
		List<Kefang> list = kefangService.queryKefangList(kefang);
		request.setAttribute("kefangList", list);
		return "/web/index.jsp";
	}
	
	
	@RequestMapping(value="/register")
	public String register(Loginuser loginuser,HttpServletRequest request) throws Exception{
		loginuserService.insertLoginuser(loginuser);
		request.setAttribute("messageInfo", "注册成功！");
		Kefang kf=new Kefang();
		return this.index(kf, request);
	}
	
	@RequestMapping(value="/userlogin")
	public String login(Loginuser loginuser,HttpServletRequest request) throws Exception{
		List<Loginuser> list = loginuserService.queryLoginuserList(loginuser);
		if(list!=null && list.size()>0){
			Loginuser luser = list.get(0);
			request.getSession().setAttribute("currentUser", luser);
			Kefang kf=new Kefang();
			request.setAttribute("messageInfo", "登录成功！");
			return this.index(kf, request);
		}else{
			request.setAttribute("messageInfo", "用户名密码错误！");
			return "/web/login.jsp";
		}
		 
		
	}
	
	@RequestMapping(value="/userloginout")
	public String userloginout(Loginuser loginuser,HttpServletRequest request) throws Exception{
		 
		request.getSession().setAttribute("currentUser",null);
		request.getSession().invalidate();
		Kefang kf=new Kefang();
		return this.index(kf, request);
	}
	
	
	@RequestMapping(value="/upuserinfo")
	public String upuserinfo(Loginuser loginuser,HttpServletRequest request) throws Exception{
		loginuserService.updateLoginuser(loginuser);
		request.getSession().setAttribute("currentUser", loginuser);
		request.setAttribute("messageInfo", "修改成功！");
		Kefang kf=new Kefang();
		return "/web/userinfo.jsp";
	}
	

	@RequestMapping(value="/hdlist")
	public String hdlist(Huodong huodong,HttpServletRequest request) throws Exception{
		List<Huodong> list = huodongService.queryHuodongList(huodong);
		request.setAttribute("huodongList", list);
		return "/web/huodonglist.jsp";
	}
	
	@RequestMapping(value="/hdview")
	public String hdview(int id,HttpServletRequest request) throws Exception{
		Huodong huodong = huodongService.queryHuodongById(id);
		request.setAttribute("huodong", huodong);
		return "/web/huodongdetail.jsp";
	}
	
	
	@RequestMapping(value="/kfview")
	public String kfview(int id,HttpServletRequest request) throws Exception{
		Kefang kefang = kefangService.queryKefangById(id);
		request.setAttribute("kefang", kefang);
		return "/web/kefangdetail.jsp";
	}
	
	@RequestMapping(value="/yding")
	public String yding(int id,HttpServletRequest request) throws Exception{
		Kefang kefang = kefangService.queryKefangById(id);
		request.setAttribute("kefang", kefang);
		return "/web/yuding.jsp";
	}
	
	@RequestMapping(value="/fwlist")
	public String fwlist(Fuwu fuwu,HttpServletRequest request) throws Exception{
		List<Fuwu> list = fuwuService.queryFuwuList(fuwu);
		request.setAttribute("fuwuList", list);
		return "/web/fuwulist.jsp";
	}
	
	@RequestMapping(value="/fwview")
	public String fwview(int id,HttpServletRequest request) throws Exception{
		Fuwu fuwu = fuwuService.queryFuwuById(id);
		request.setAttribute("fuwu", fuwu);
		return "/web/fuwudetail.jsp";
	}
	
 
	@RequestMapping(value="/aboutus")
	public String aboutus(int id,HttpServletRequest request) throws Exception{
		Jiudian jiudian = jiudianService.queryJiudianById(id);
		request.setAttribute("jiudian", jiudian);
		return "/web/aboutus.jsp";
	}
	

	
	@RequestMapping(value="/tslist")
	public String tslist(Tousu tousu,HttpServletRequest request) throws Exception{
		List<Tousu> list = tousuService.queryTousuList(tousu);
		request.setAttribute("tousuList", list);
		return "/web/tousu.jsp";
	}
	
	
	@RequestMapping(value="/ts")
	public String ts(Tousu tousu,HttpServletRequest request) throws Exception{
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String shijian = format.format(new Date());
		tousu.setTssj(shijian);
		Loginuser user = (Loginuser) request.getSession().getAttribute("currentUser");
		tousu.setTsr(user.getName());
		tousuService.insertTousu(tousu);
		request.setAttribute("messageInfo", "感谢您的反馈！");
		tousu = new Tousu();
		return this.tslist(tousu, request);
	}
	
	
	
	@RequestMapping(value="/submitorder")
	public String submitorder(int id,HttpServletRequest request) throws Exception{
		Loginuser user = (Loginuser) request.getSession().getAttribute("currentUser");
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String shijian = format.format(new Date());
		String rzrq = format.format(new Date());//日期转换
		String ldrq= format.format(new Date());
		
		Kefang kefang = kefangService.queryKefangById(id);
		Dingdan dingdan=new Dingdan();
		dingdan.setBid(id);
		dingdan.setUid(user.getId());
		dingdan.setJe(kefang.getJg());
		dingdan.setShijian(shijian);
		dingdan.setRzrq(rzrq);
		dingdan.setLdrq(ldrq);
		dingdan.setType(1);
		dingdan.setName(kefang.getName());
		dingdan.setZt("已预订");
		dingdanService.insertDingdan(dingdan);
		kefang.setSl(kefang.getSl()-1);
		kefangService.updateKefang(kefang);
		
		return this.myorder(dingdan, request);
	}
	
	@RequestMapping(value="/submitorderfw")
	public String submitorderfw(int id,HttpServletRequest request) throws Exception{
		Loginuser user = (Loginuser) request.getSession().getAttribute("currentUser");
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String shijian = format.format(new Date());
		Fuwu fuwu = fuwuService.queryFuwuById(id);
		Dingdan dingdan=new Dingdan();
		dingdan.setBid(id);
		dingdan.setUid(user.getId());
		dingdan.setJe(fuwu.getJg());
		dingdan.setShijian(shijian);
		dingdan.setType(2);
		dingdan.setName(fuwu.getName());
		dingdan.setZt("已预订");
		dingdanService.insertDingdan(dingdan);
		
		return this.myorder(dingdan, request);
	}
	
	@RequestMapping(value="/yudingdan")
	public String yudingdan(int id,HttpServletRequest request) throws Exception{
		Loginuser user = (Loginuser) request.getSession().getAttribute("currentUser");
		//SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Kefang kefang = kefangService.queryKefangById(id);
		request.setAttribute("kefang", kefang);
		kefang.getType();//客房类型
		Dingdan dingdan=new Dingdan();
		dingdan.getBid();
		dingdan.getUname();
		//dingdan.getName();
		dingdan.getJe();
		dingdan.getType();
		dingdan.getRzrq();
		dingdan.getLdrq();
		return "/web/yuding.jsp";
	}


	@RequestMapping(value="/myorder")
	public String myorder(Dingdan dingdan,HttpServletRequest request) throws Exception{
		Loginuser user = (Loginuser) request.getSession().getAttribute("currentUser");
		dingdan.setUid(user.getId());
		List<Dingdan> list = dingdanService.queryDingdanList(dingdan);
		request.setAttribute("dingdanList", list);
		return "/web/myorder.jsp";
	}
	
	@RequestMapping(value="/qxorder")
	public String qxorder(int id,HttpServletRequest request) throws Exception{
		Dingdan dingdan = new Dingdan();
		dingdan.setId(id);
		dingdan.setZt("已取消");
		dingdanService.qxDingdan(dingdan);
		if(dingdan.getType()==1){
			Kefang kefang = kefangService.queryKefangById(dingdan.getBid());
			kefang.setSl(kefang.getSl()+1);
			kefangService.updateKefang(kefang);
		}
		dingdan=new Dingdan();
		return this.myorder(dingdan, request);
	}
	
	@RequestMapping(value="/qrorder")
	public String qrorder(int id,HttpServletRequest request) throws Exception{
		Dingdan dingdan = new Dingdan();
		dingdan.setId(id);
		dingdan.setZt("已入住");
		dingdanService.qrDingdan(dingdan);
		if(dingdan.getType()==1){
			Kefang kefang = kefangService.queryKefangById(dingdan.getBid());
			/*kefang.setSl(kefang.getSl()-1);*/
			kefangService.updateKefang(kefang);
		}
		dingdan=new Dingdan();
		return this.myorder(dingdan, request);
	}
 
}
