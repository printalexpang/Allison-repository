package com.jiudian.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.jiudian.mapper.SendMapper;
import com.jiudian.pojo.Loginuser;

public class PhoneServiceImpl {
    @Autowired
	private SendMapper sendMapper;
	 
    public boolean loginList(String name, String phone) {
        List<Loginuser> login = sendMapper.loginList(name,phone);
        int i = login.size();
        System.out.print(i);
        return i != 0;
    }
 

}
