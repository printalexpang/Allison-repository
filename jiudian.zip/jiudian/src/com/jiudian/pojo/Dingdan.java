package com.jiudian.pojo;

import java.io.Serializable;

 
public class Dingdan implements Serializable{
 
 
	private static final long serialVersionUID = 1L;
	private Integer id;//主键
	private int bid; 
	private int type; //1 客房  2 其他服务
	private int uid;
	private String je;
	private String shijian;
	private String name;
	private String zt;
	private String uname;
	private String rzrq;
	private String ldrq;//离店日期
	
	
	
	public String getLdrq() {
		return ldrq;
	}
	public void setLdrq(String ldrq) {
		this.ldrq = ldrq;
	}
	public String getRzrq() {
		return rzrq;
	}
	public void setRzrq(String rzrq) {
		this.rzrq = rzrq;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public int getBid() {
		return bid;
	}
	public void setBid(int bid) {
		this.bid = bid;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public String getJe() {
		return je;
	}
	public void setJe(String je) {
		this.je = je;
	}
	public String getShijian() {
		return shijian;
	}
	public void setShijian(String shijian) {
		this.shijian = shijian;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getZt() {
		return zt;
	}
	public void setZt(String zt) {
		this.zt = zt;
	}
	
	
    
}
