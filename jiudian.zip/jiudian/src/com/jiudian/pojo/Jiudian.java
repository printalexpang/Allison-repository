package com.jiudian.pojo;

import java.io.Serializable;

 
public class Jiudian implements Serializable{
 
 
	private static final long serialVersionUID = 1L;
	private Integer id;//主键
	private String xinxi;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getXinxi() {
		return xinxi;
	}
	public void setXinxi(String xinxi) {
		this.xinxi = xinxi;
	} 
	
	
	
    
}
