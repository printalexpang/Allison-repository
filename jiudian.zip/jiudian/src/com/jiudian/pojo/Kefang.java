package com.jiudian.pojo;

import java.io.Serializable;

import com.jiudian.util.HtmlSplit;

 
public class Kefang implements Serializable{
 
 
	private static final long serialVersionUID = 1L;
	private Integer id;//主键
	private String name;
	private String type;
	private String ms;
	private String pic;
	private String jg;
	private String fujian;
	
	private String mss;
	
	private int sl;
	private int ydsl;
	
	
	
	public int getSl() {
		return sl;
	}
	public void setSl(int sl) {
		this.sl = sl;
	}
	public int getYdsl() {
		return ydsl;
	}
	public void setYdsl(int ydsl) {
		this.ydsl = ydsl;
	}
	public String getMss() {
		if(ms!=null && !ms.equals("")){
			mss = HtmlSplit.delHTMLTag(ms);
		}
		return mss;
	}
	public String getFujian() {
		return fujian;
	}
	public void setFujian(String fujian) {
		this.fujian = fujian;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getMs() {
		return ms;
	}
	public void setMs(String ms) {
		this.ms = ms;
	}
	public String getPic() {
		return pic;
	}
	public void setPic(String pic) {
		this.pic = pic;
	}
	public String getJg() {
		return jg;
	}
	public void setJg(String jg) {
		this.jg = jg;
	}
	
    
}
