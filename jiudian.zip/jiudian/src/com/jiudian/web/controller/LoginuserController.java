package com.jiudian.web.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.jiudian.pojo.Loginuser;
import com.jiudian.service.LoginuserService;
 
@Controller
@RequestMapping("/loginuser")
public class LoginuserController {
	@Autowired
	private LoginuserService loginuserService;
	
	@RequestMapping(value="/list")
	public String list(Loginuser loginuser,HttpServletRequest request) throws Exception{
		List<Loginuser> list = loginuserService.queryLoginuserList(loginuser);
		request.setAttribute("loginuserList", list);
		return "/loginuser/loginuserlist.jsp";
	}
	
	@RequestMapping(value="/addloginuser")
	public String addloginuser(Loginuser loginuser,HttpServletRequest request) throws Exception{
		loginuserService.insertLoginuser(loginuser);
		loginuser=new Loginuser();
		return this.list(loginuser, request);
	}
	
	@RequestMapping(value="/toupdateloginuser")
	public String toupdateloginuser(int id,HttpServletRequest request) throws Exception{
		Loginuser loginuser=loginuserService.queryLoginuserById(id);
		request.setAttribute("loginuser", loginuser);
		return "/loginuser/loginuserupdate.jsp";
	}
	
	@RequestMapping(value="/deleteloginuser")
	public String deleteloginuser(int id,HttpServletRequest request) throws Exception{
		loginuserService.deleteLoginuser(id);
		return "/loginuser/list";
	}
	
	@RequestMapping(value="/updateloginuser")
	public String updateloginuser(Loginuser loginuser,HttpServletRequest request) throws Exception{
		loginuserService.updateLoginuser(loginuser);
		loginuser=new Loginuser();
		return this.list(loginuser, request);
	}
	
}
