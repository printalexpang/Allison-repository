package com.jiudian.service;

import java.util.List;

import com.jiudian.pojo.*;
public interface RecordService {//为图表做测试类
    List<Dingdan>  selecMore();
}