package com.jiudian.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jiudian.mapper.HuodongMapper;
import com.jiudian.pojo.Huodong;
import com.jiudian.service.HuodongService;


 
@Service
public class HuodongServiceImpl implements HuodongService {
	@Autowired
	private HuodongMapper huodongMapper;

	@Override
	public List<Huodong> queryHuodongList(Huodong huodong) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		if(huodong!=null){
			map.put("name", huodong.getName());
		}
		
		List<Huodong> getHuodong = huodongMapper.query(map);
		return getHuodong;
	}

	public int insertHuodong(Huodong huodong) throws Exception {
		huodongMapper.insertHuodong(huodong);
		return huodong.getId();
	}

	public int deleteHuodong(int id) throws Exception {
		return huodongMapper.deleteHuodong(id);
	}

	public int updateHuodong(Huodong huodong) throws Exception {
		return huodongMapper.updateHuodong(huodong);
	}
	
	public Huodong queryHuodongById(int id) throws Exception {
		return huodongMapper.queryHuodongById(id);
	}

 

}
