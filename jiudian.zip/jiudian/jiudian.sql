﻿# MySQL-Front 5.0  (Build 1.0)

/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE */;
/*!40101 SET SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES */;
/*!40103 SET SQL_NOTES='ON' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS */;
/*!40014 SET FOREIGN_KEY_CHECKS=0 */;


# Host: localhost    Database: jiudian
# ------------------------------------------------------
# Server version 5.5.30

DROP DATABASE IF EXISTS `jiudian`;
CREATE DATABASE `jiudian` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `jiudian`;

#
# Table structure for table dingdan
#

CREATE TABLE `dingdan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bid` int(11) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `je` varchar(50) DEFAULT NULL,
  `shijian` varchar(50) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `uid` int(11) DEFAULT NULL,
  `zt` varchar(50) DEFAULT NULL,
  `rzrq` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
INSERT INTO `dingdan` VALUES (2,1,1,'458','2016-12-29 00:31:55','豪华单间',1,'已取消',NULL);
INSERT INTO `dingdan` VALUES (3,1,1,'100','2016-12-29 00:49:29','GOLF练习场',1,'已取消',NULL);
INSERT INTO `dingdan` VALUES (6,1,1,'458','2016-12-29 01:46:46','豪华单间',3,'已取消',NULL);
INSERT INTO `dingdan` VALUES (7,2,1,'900','2016-12-29 01:46:57','会议主会场展厅',3,'已预订',NULL);
INSERT INTO `dingdan` VALUES (8,1,1,'458','2017-01-02 16:52:17','豪华单间',2,'已取消',NULL);
INSERT INTO `dingdan` VALUES (9,1,1,'458','2017-01-02 17:11:21','豪华单间',2,'已预订',NULL);
/*!40000 ALTER TABLE `dingdan` ENABLE KEYS */;
UNLOCK TABLES;

#
# Table structure for table fuwu
#

CREATE TABLE `fuwu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL,
  `ms` varchar(200) DEFAULT NULL,
  `jg` varchar(50) DEFAULT NULL,
  `pic` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
INSERT INTO `fuwu` VALUES (1,'GOLF练习场','湖泉高尔夫练习场坐落于生态园南园，占地17000平米，拥有44个练习打位及1个练习果岭。球场集运动休闲与娱乐为一体，设有高尔夫用品专卖店，更有专业教练现场指导，让您享受到高尔夫的无限乐趣','100','/upload/c5.jpg');
INSERT INTO `fuwu` VALUES (2,'会议主会场展厅','地点：会展一楼\r\n会议室类型：多功能厅\r\n面积：1187㎡\r\n标准座位及布置类型：课桌式布置、U型式布置、回型式布置、分组式布置、根据客户要求布置。\r\n收费配置构成：绿植、5名专职服务员及1名设备操作人员。\r\n半天价：\r\n全天价：\r\n会议室相关配置：提供音响、投影，能满足会议视频资料展示，和多位宾客的讲话扩音功能。\r\n容纳人数：450人','900','/upload/1482944946343.jpg');
INSERT INTO `fuwu` VALUES (3,'ww','<p>eeeeee</p><p><img src=\"/jiudian//ueditor/jsp/upload/image/20170102/1483343461909078651.jpg\" title=\"1483343461909078651.jpg\" alt=\"588e9f0155af21fbca144eb4650d7af2.jpg\"/></p>','134','/upload/1483343472635.jpg');
/*!40000 ALTER TABLE `fuwu` ENABLE KEYS */;
UNLOCK TABLES;

#
# Table structure for table huodong
#

CREATE TABLE `huodong` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `ms` text,
  `shijian` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
INSERT INTO `huodong` VALUES (1,'酒店五周年店庆酬宾','感恩回馈第一重——超值优惠酬宾礼：即日起至12月31日，预订湖泉天邑芳蹊院（原价5800元）、月度台（原价4800元）可享3200元/套/晚感恩回馈价，预订湖泉天邑紫桂阁（原价3800元）可享2800元/套/晚感恩回馈价，以上特惠价已包含15%服务费。感恩回馈第一重——超值优惠酬宾礼：即日起至12月31日，预订湖泉天邑芳蹊院（原价5800元）、月度台（原价4800元）可享3200元/套/晚感恩回馈价，预订湖泉天邑紫桂阁（原价3800元）可享2800元/套/晚感恩回馈价，以上特惠价已包含15%服务费。感恩回馈第一重——超值优惠酬宾礼：即日起至12月31日，预订湖泉天邑芳蹊院（原价5800元）、月度台（原价4800元）可享3200元/套/晚感恩回馈价，预订湖泉天邑紫桂阁（原价3800元）可享2800元/套/晚感恩回馈价，以上特惠价已包含15%服务费。','2016-12-28');
INSERT INTO `huodong` VALUES (2,'喜迎元旦，大放价','元旦大放价，5折起','2016-12-28');
INSERT INTO `huodong` VALUES (3,'元旦放假通知','元旦放假三天','2016-12-29');
INSERT INTO `huodong` VALUES (4,'过年大放送','5折优惠','2016-12-29');
/*!40000 ALTER TABLE `huodong` ENABLE KEYS */;
UNLOCK TABLES;

#
# Table structure for table jiudian
#

CREATE TABLE `jiudian` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `xinxi` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
INSERT INTO `jiudian` VALUES (1,'<p>wwwwwwwwwwwwwww</p><p><img src=\"/jiudian//ueditor/jsp/upload/image/20170102/1483342765479004393.jpg\" title=\"1483342765479004393.jpg\" alt=\"ab321a5859a473110d9e195e5edf7158.jpg\"/></p>');
/*!40000 ALTER TABLE `jiudian` ENABLE KEYS */;
UNLOCK TABLES;

#
# Table structure for table kefang
#

CREATE TABLE `kefang` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `type` varchar(30) DEFAULT NULL,
  `ms` text,
  `pic` varchar(300) DEFAULT NULL,
  `jg` varchar(30) DEFAULT NULL,
  `sl` int(11) DEFAULT '0',
  `ydsl` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
INSERT INTO `kefang` VALUES (1,'豪华单间','豪华单间','面积：56㎡\r\n楼层：联排三层\r\n床宽：2.1m*2m\r\n入住人数：2人\r\n宽带：免费有线宽带、覆盖wifi\r\n早餐：可自行选择是否需要双人早餐\r\n泡浴：可自行选择是否需要双人泡浴\r\n赠送湖泉礼包券：大堂吧咖啡体验劵、温泉理疗代金券、湖泉餐饮代金劵、湖泉KTV免包房欢唱劵、球类运动体验劵。\r\n停车：免费','/upload/123.jpg','458',1,0);
INSERT INTO `kefang` VALUES (2,'普通单间','普通单间','面积：38㎡ 楼层：4层 床宽：1.8m*2m 入住人数：2人 宽带：免费有线宽带、覆盖wifi 早餐：可自行选择是否需要双人早餐 泡浴：可自行选择是否需要双人泡浴 赠送湖泉礼包券：大堂吧咖啡体验劵、温泉理疗代金券、湖泉餐饮代金劵、湖泉KTV免包房欢唱劵、球类运动体验劵。 停车：免费','/upload/1482944783726.jpg','208',10,0);
INSERT INTO `kefang` VALUES (3,'111','22222','<p>dddddddd</p><p><img src=\"/jiudian//ueditor/jsp/upload/image/20170102/1483343002187021108.jpg\" title=\"1483343002187021108.jpg\" alt=\"w.jpg\"/></p>','/upload/1483343012393.jpg','123',10,0);
/*!40000 ALTER TABLE `kefang` ENABLE KEYS */;
UNLOCK TABLES;

#
# Table structure for table loginuser
#

CREATE TABLE `loginuser` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) DEFAULT NULL,
  `pwd` varchar(20) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL,
  `telphone` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
INSERT INTO `loginuser` VALUES (1,'test','123456','张三封','15529598858');
INSERT INTO `loginuser` VALUES (2,'bibi','123456','张三三','18777778787');
INSERT INTO `loginuser` VALUES (3,'baba','123456','李四','18677777171');
/*!40000 ALTER TABLE `loginuser` ENABLE KEYS */;
UNLOCK TABLES;

#
# Table structure for table tousu
#

CREATE TABLE `tousu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) DEFAULT NULL,
  `ms` varchar(400) DEFAULT NULL,
  `tsr` varchar(20) DEFAULT NULL,
  `tssj` varchar(30) DEFAULT NULL,
  `replay` varchar(200) DEFAULT NULL,
  `hfsj` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
INSERT INTO `tousu` VALUES (2,NULL,'不错的样子，可以在好点','张三封','2016-12-28 23:56:52','谢谢','2016-12-28 23:57:02');
INSERT INTO `tousu` VALUES (3,NULL,'服务态度不太好，希望改进','张三三','2016-12-29 01:30:11','谢谢您的建议，我们会尽快改进','2016-12-29 01:31:06');
INSERT INTO `tousu` VALUES (4,NULL,'不错','李四','2016-12-29 01:47:11','谢谢','2016-12-29 01:48:00');
/*!40000 ALTER TABLE `tousu` ENABLE KEYS */;
UNLOCK TABLES;

#
# Table structure for table user
#

CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(32) NOT NULL COMMENT '用户名称',
  `pwd` varchar(255) DEFAULT NULL,
  `utype` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
INSERT INTO `user` VALUES (1,'zhangsan','8888','超级管理员');
INSERT INTO `user` VALUES (3,'admin','123456','普通管理员');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
