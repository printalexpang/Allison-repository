package com.jiudian.pojo;

import java.io.Serializable;

 
public class Huodong implements Serializable{
 
 
	private static final long serialVersionUID = 1L;
	private Integer id;//主键
	private String name; 
	private String ms;  
	private String shijian;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMs() {
		return ms;
	}
	public void setMs(String ms) {
		this.ms = ms;
	}
	public String getShijian() {
		return shijian;
	}
	public void setShijian(String shijian) {
		this.shijian = shijian;
	}
	
	
	
	
    
}
