package com.jiudian.mapper;
import com.jiudian.pojo.*;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;
 
import java.util.List;
@Repository
public interface SendMapper {
	 List<Loginuser> loginList(@Param("name") String name,
             @Param("telphone") String telphone);
}
