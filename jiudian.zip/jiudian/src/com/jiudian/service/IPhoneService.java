package com.jiudian.service;

public interface IPhoneService {
    boolean loginList(String name, String phone);
}
