// JavaScript Document
$(document).ready(function() {
	
    /*$(".menu>ul>li").hover(function(){
		$(this).find("a:first").addClass("cur");					 
		$(this).find("ul").stop(true,true).slideDown(500,"easeOutBounce");
	},function(){
		$(this).find("a:first").removeClass("cur");
		$(this).find("ul").stop(true,true).slideUp(500);				
	})
	var winW = $(window).width();
	$(".focus_wrap").width(winW);
	$(".focus").css("left",(winW-1920)/2);
	$(".menu").css("left",(winW-1000)/2);
	$(".order").css("left",(winW-1000)/2);
	$(".prev_button").css("left",(1920-winW)/2);
	$(".next_button").css("right",(1920-winW)/2);
	$(window).resize(function(){
		winW = $(window).width();
		if(winW<=1000){
			winW = 1000;
		}
		$(".focus_wrap").width(winW);
		$(".focus").css("left",(winW-1920)/2);
		$(".menu").css("left",(winW-1000)/2);
		$(".order").css("left",(winW-1000)/2);
		$(".prev_button").css("left",(1920-winW)/2);
		$(".next_button").css("right",(1920-winW)/2);
	})*/
	
});
